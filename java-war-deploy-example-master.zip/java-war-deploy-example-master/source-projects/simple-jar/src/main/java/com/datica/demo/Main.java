package com.datica.demo;

public class Main {
	public static void main(String[] args) {
		System.out.println("Hello v1 from the JAR file: " + new java.util.Date());
	}
}
